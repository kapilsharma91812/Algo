package com.kapil.sample;

import android.app.Application;
import android.content.SharedPreferences;
import android.widget.Toast;


import com.kapil.sample.dagger.DaggerServiceComponent;
import com.kapil.sample.dagger.ServiceComponent;


/**
 * Created by kapilsharma on 18/11/17.
 */
public class MainApplication extends Application {
    private static MainApplication instance;
    private ServiceComponent component;

    public static MainApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        component = DaggerServiceComponent.builder().build();
    }

    public ServiceComponent component() {
        return component;
    }


}

package com.kapil.sample.network.data;

import com.google.gson.annotations.SerializedName;

import org.parceler.Parcel;


/**
 * Created by kapilsharma on 11/07/17.
 */

@Parcel
public class Product {

    @SerializedName("variants")
    public Variant variant;
}

package com.kapil.sample.fragments;


import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.kapil.sample.R;
import com.kapil.sample.activities.ListingActivity;
import com.kapil.sample.adapters.ItemSelectAdapter;
import com.kapil.sample.network.data.Variant;

import org.parceler.Parcels;

import java.util.HashSet;

import rx.subjects.PublishSubject;
import rx.subscriptions.CompositeSubscription;


/**
 * Created by kapilsharma on 18/11/17.
 */

public class ProductsFragment extends Fragment implements View.OnClickListener {

    private static final String TAG = ProductsFragment.class.getSimpleName();
    private static final String ITEM_KEY = "item_keys";
    private static final String CURRENT_STEP = "current_step";
    private static final String TOTAL_STEP = "total_step";
    private static final String EXCLUSION_MAP_KEY = "exclusion_map";
    private static final String CHOOSE = "Choose ";


    private CompositeSubscription compositeSubscription = new CompositeSubscription();
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private ItemSelectAdapter itemSelectAdapter;
    private Variant.VariantGroup group;
    private HashSet<Integer> exclusionSet;
    private TextView title;
    private int currentStep;
    private TextView steptxt;
    private int totalStep;
    private PublishSubject<Integer> clickSubject;
    private int selectedVariantId;
    private Button btn;

    public ProductsFragment() {
        // Required empty public constructor
    }


    public static ProductsFragment newInstance(Variant.VariantGroup items, int currentStep, int totalStep, HashSet<Integer> exclusionSet) {
        ProductsFragment productFragment = new ProductsFragment();
        Bundle bundle = new Bundle();
        Parcelable parcelable = Parcels.wrap(items);
        Parcelable parcelableSet = Parcels.wrap(exclusionSet);
        bundle.putParcelable(ITEM_KEY, parcelable);
        bundle.putParcelable(EXCLUSION_MAP_KEY, parcelableSet);
        bundle.putInt(CURRENT_STEP, currentStep);
        bundle.putInt(TOTAL_STEP, totalStep);
        productFragment.setArguments(bundle);
        return productFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        group = Parcels.unwrap(getArguments().getParcelable(ITEM_KEY));
        exclusionSet = Parcels.unwrap(getArguments().getParcelable(EXCLUSION_MAP_KEY));
        currentStep = getArguments().getInt(CURRENT_STEP);
        totalStep = getArguments().getInt(TOTAL_STEP);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_listing, container, false);
        title = (TextView) view.findViewById(R.id.title);
        steptxt = (TextView) view.findViewById(R.id.step);
        btn = (Button) view.findViewById(R.id.btn);
        btn.setOnClickListener(this);
        title.setText(CHOOSE + group.name);
        steptxt.setText((currentStep+ 1) + " / " + totalStep);
        recyclerView = (RecyclerView) view.findViewById(R.id.feed_view);
        linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        itemSelectAdapter = new ItemSelectAdapter(getActivity(), group.variations, exclusionSet);
        clickSubject = itemSelectAdapter.getClickSubject();
        clickSubject.subscribe(index -> {
            selectedVariantId = index;
            Log.d("Click:" , ""+ selectedVariantId);
        }, error -> {});
        recyclerView.setAdapter(itemSelectAdapter);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onClick(View v) {
        ((ListingActivity)getActivity()).onContinueClick(selectedVariantId, currentStep);
    }
}

package com.kapil.sample.network.data;

import com.google.gson.annotations.SerializedName;

import org.parceler.Parcel;

import java.util.List;

/**
 * Created by kapilsharma on 17/11/17.
 */

@Parcel
public class Variant {
    @SerializedName("variant_groups")
    public List<VariantGroup> variantGroup;

    @SerializedName("exclude_list")
    public List<List<Exclusion>> exclusionList;





    @Parcel
    public static class VariantGroup {
        @SerializedName("group_id")
        public int groupId;

        @SerializedName("name")
        public String name;

        @SerializedName("variations")
        public List<Variation> variations;


    }

    @Parcel
    public static class Variation {

        @SerializedName("price")
        public int price;

        @SerializedName("name")
        public String name;

        @SerializedName("default")
        public int defaultValue;

        @SerializedName("id")
        public int id;

        @SerializedName("inStock")
        public int inStock;

        @SerializedName("isVeg")
        public int isVeg;

        public boolean isChecked;


    }

    @Parcel
    public static class Exclusion {
        @SerializedName("group_id")
        public int groupId;

        @SerializedName("variation_id")
        public int variationId;

    }



}

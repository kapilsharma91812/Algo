package com.kapil.sample.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import com.kapil.sample.R;
import com.kapil.sample.network.data.Variant;

import java.util.HashSet;
import java.util.List;

import rx.subjects.PublishSubject;

/**
 * Created by kapilsharma on 18/11/17.
 */

public class ItemSelectAdapter extends RecyclerView.Adapter<ItemSelectAdapter.ItemHolder> {

    private static final String TAG = ItemSelectAdapter.class.getSimpleName();
    private final HashSet<Integer> exclusionSet;

    private List<Variant.Variation> variantList;
    private LayoutInflater inflater;
    private PublishSubject<Integer> clickSubject;
    private static RadioButton lastChecked = null;
    private static int lastCheckedPos = 0;

    public ItemSelectAdapter(Context context, List<Variant.Variation> variantList, HashSet<Integer> exclusionSet) {
        this.variantList = variantList;
        inflater = LayoutInflater.from(context);
        clickSubject = PublishSubject.create();
        lastCheckedPos = 0;
        this.exclusionSet = exclusionSet;
    }


    @Override
    public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ItemHolder(inflater.inflate(R.layout.item_list, parent, false));
    }

    @Override
    public void onBindViewHolder(ItemHolder holder, int position) {
        if (exclusionSet != null && exclusionSet.contains(variantList.get(position).id)) {
            holder.rb.setVisibility(View.GONE);
        } else {
            holder.rb.setVisibility(View.VISIBLE);
        }
        holder.rb.setChecked(variantList.get(position).isChecked);
        holder.rb.setText(variantList.get(position).name);
        holder.rb.setTag(new Integer(position));
        if (variantList.get(position).isChecked) {
            lastChecked = holder.rb;
            lastCheckedPos = position;
        }
    }
    public int getCheckedPosition() {
        return lastCheckedPos;
    }

    @Override
    public int getItemCount() {
        return variantList.size();
    }

    public class ItemHolder extends RecyclerView.ViewHolder {
        private final RadioButton rb;

        public ItemHolder(View itemView) {
            super(itemView);
            rb = (RadioButton) itemView.findViewById(R.id.radio);
            itemView.setOnClickListener(v -> {
                clickSubject.onNext(getAdapterPosition());
            });
            rb.setOnClickListener(v -> onItemClick());
        }
        private void onItemClick() {
            int clickedPos = ((Integer) rb.getTag()).intValue();
            if (rb.isChecked()) {
                if (lastChecked != null && lastCheckedPos != clickedPos) {
                    lastChecked.setChecked(false);
                    variantList.get(lastCheckedPos).isChecked = false;
                }
            } else {
                rb.setChecked(true);
            }
            lastChecked = rb;
            lastCheckedPos = clickedPos;
            variantList.get(clickedPos).isChecked = true;
            clickSubject.onNext(variantList.get(clickedPos).id);
        }
    }

    public PublishSubject<Integer> getClickSubject() {
        return clickSubject;
    }
}

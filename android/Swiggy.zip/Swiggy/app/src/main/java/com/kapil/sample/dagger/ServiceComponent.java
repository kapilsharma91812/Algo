package com.kapil.sample.dagger;


import com.kapil.sample.network.NetworkModule;
import com.kapil.sample.network.api.ProductApi;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by kapilsharma on 18/11/17.
 */

@Singleton
@Component(modules = {NetworkModule.class})
public interface ServiceComponent {
    ProductApi getProductApi();
}

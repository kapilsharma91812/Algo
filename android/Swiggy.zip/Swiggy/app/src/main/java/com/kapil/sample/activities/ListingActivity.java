package com.kapil.sample.activities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.kapil.sample.MainApplication;
import com.kapil.sample.R;
import com.kapil.sample.fragments.ProductsFragment;
import com.kapil.sample.network.data.Product;
import com.kapil.sample.network.data.Variant;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import rx.Subscriber;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by kapilsharma on 18/11/17.
 */

public class ListingActivity extends BaseActivity {
    private static final String TAG = ListingActivity.class.getSimpleName();
    private CompositeSubscription compositeSubscription ;
    private Product product;
    private HashMap<Integer, HashSet<Integer>> exclusionMap;
    private View loaderView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        compositeSubscription = new CompositeSubscription();
        setContentView(R.layout.activity_listing);
        loaderView = findViewById(R.id.tz_trnx_loader);
        initializeToolbar(false, getString(R.string.swiggy_products),true);
        loadProducts();

    }

    void loadProducts() {
        loaderView.setVisibility(View.VISIBLE);
        Subscription subs = MainApplication.getInstance().component().getProductApi().getProducts()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Product>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.d(TAG, "onError: " + e.getMessage());
                        loaderView.setVisibility(View.GONE);
                        Toast.makeText(ListingActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onNext(Product product) {
                        loaderView.setVisibility(View.GONE);
                        ListingActivity.this.product = product;
                        Log.d(TAG, "onNext: " + product.variant.variantGroup.size());
                        processExclusionList(product.variant.exclusionList);
                        renderProductsUI(0, -1);


                    }
                });
        compositeSubscription.add(subs);
    }

    private void processExclusionList(List<List<Variant.Exclusion>> exclusionLists) {
        exclusionMap = new HashMap<>(exclusionLists.size());
        for (List<Variant.Exclusion> exclusionList : exclusionLists ) {
            if (!exclusionMap.containsKey(exclusionList.get(1).variationId)) {
                exclusionMap.put(exclusionList.get(0).variationId, new HashSet<>());
            }
            HashSet<Integer> exclusionSet = exclusionMap.get(exclusionList.get(0).variationId);
            exclusionSet.add(exclusionList.get(1).variationId);
        }
    }

    private void renderProductsUI(int step, int selectedVariantId) {
        if (step < product.variant.variantGroup.size()) {
            Variant.VariantGroup variantGroup = product.variant.variantGroup.get(step);
            ProductsFragment fragment = ProductsFragment.newInstance(variantGroup, step, product.variant.variantGroup.size(), exclusionMap.get(selectedVariantId));
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.item_detail_container, fragment)
                    .addToBackStack(null)
                    .commit();
        }
    }

    public void onContinueClick(int selectedVariantId, int currentStep) {
        Log.d("click" , "Recived click:" + selectedVariantId);
        renderProductsUI(currentStep + 1, selectedVariantId);
    }

    @Override
    public void onBackPressed(){
        if (getSupportFragmentManager().getBackStackEntryCount() == 1){
            finish();
        }
        else {
            super.onBackPressed();
        }
    }

}

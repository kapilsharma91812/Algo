package com.kapil.sample.network.api;


import com.kapil.sample.network.data.Product;


import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by kapilsharma on 11/07/17.
 */
public interface ProductApi {

    @GET("bins/3b0u2")
    Observable<Product> getProducts();
}
